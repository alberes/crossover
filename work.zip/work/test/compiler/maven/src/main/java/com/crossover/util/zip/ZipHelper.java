package com.crossover.util.zip;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class ZipHelper {

	public static final int BUFFER_SIZE = 1024;
	
	/**
	 * Unzip files
	 * 
	 * @param inputZipFile
	 * @param outputZipFile
	 * @return List with names of files
	 * @throws IOException
	 */
	public List<String> unzipFile(String inputZipFile, String outputZipFile) throws IOException{
		byte[] buffer = new byte[ZipHelper.BUFFER_SIZE];
		List<String> fileList = new ArrayList<String>();
		return fileList;
	}
	
	/**
	 * Compress all files
	 * 
	 * @param basePath
	 * @param ext
	 * @param outputZipFile
	 * @return List with names of files
	 * @throws IOException
	 */
	public String zipFile(String basePath, String ext, String outputZipFile) throws IOException{
		
		return outputZipFile;
	}
}
