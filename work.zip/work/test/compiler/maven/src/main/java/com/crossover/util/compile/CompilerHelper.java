package com.crossover.util.compile;

import java.util.ArrayList;
import java.util.List;

public class CompilerHelper {
	
	public List<String> compile(String sourcePath, String classesPath){
		//http://bugs.java.com/bugdatabase/view_bug.do?bug_id=7181951
        List<String> messages = new ArrayList<String>();
        return messages;
	}
	
	public int compileMavenProject(String pathPom, List<String> commands) {
		return 0;
	}


}
