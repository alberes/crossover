package com.test;

public class Test3{

	public void print(){
		System.out.println("ola");
	}
}
