package com.test;

public class Test2{

	public void print(){
		System.out.println("ola");
	}
}
