package com.test;

public class Test1{

	public void print(){
		System.out.println("ola");
	}
}
